Brazil 2D Android WebView Project

Website:
https://brazil-2d.yehtetaung7655.workers.dev/

App name:
Brazil 2D

Package:
com.brazil2d.app

How to build APK in Android Studio:
1. Extract this ZIP.
2. Open the Brazil2D_Android folder in Android Studio.
3. Let Gradle sync finish.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The APK will be generated under app/build/outputs/apk/debug/.

Note:
This environment does not include the Android SDK/Gradle build tools, so this
ZIP contains the complete Android Studio project rather than a prebuilt APK.
